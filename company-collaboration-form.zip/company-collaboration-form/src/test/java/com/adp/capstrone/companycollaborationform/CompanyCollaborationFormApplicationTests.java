package com.adp.capstrone.companycollaborationform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanyCollaborationFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
