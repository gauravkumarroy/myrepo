package com.adp.capstrone.companycollaborationform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompanyCollaborationFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompanyCollaborationFormApplication.class, args);
	}

}
